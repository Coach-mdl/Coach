# WaterFlasks
Water Flasks TFC/Minecraft mod, inspired by Emris's Leather Water Sac for 1.7.10.

For Minecraft 1.12.2 + TerraFirmaCraft TNG.

See TerraFirmaCraft #tfc-tng-addons discord channel for support: https://invite.gg/terrafirmacraft

All code and resources used according to their published licenses.

Translations and textures welcome.

Sides of flask are knapped out of leather.
Bladders drop from bears, cows, horses, and sheep at some probability affected by butchering skill.
Bears are the most likely, and take the least skill.

Flasks now take damage, and are repairable.

Fluid level in flask is indicated by vertical bar.

## Status

Stable release! 

